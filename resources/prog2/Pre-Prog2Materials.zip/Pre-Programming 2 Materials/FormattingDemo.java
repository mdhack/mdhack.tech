
public class FormattingDemo {

	public static void main(String[] args){
		
		// the static method format of the System.out
		// object can be used to format console output.  
		
		//for every piece of data that you would like to format
		// that piece of data will be represented by a %
		// every % inside your formatted string requries 
		// an additional argument.
		
		String name = "Bubba";			//try varying the length of the name and run again
		double gpa = 4.7899991;
		System.out.format("Name: %-15s  GPA: "+gpa+"\n", name);
		
		//The first argument is always a string.  It can contain
		// plain old text as well as spaces.  Above I want to format
		// the name to ensure that any name <= 15 characters will
		//still have the same amount of space reserved for it.
		
		// The percent sign (%) indicates where I want the formatted
		// data to be placed.  For every % in the literal string I must
		//have an additional argument in the format method.
		
		// The numbers indicate how much space I want.  
		// Here I want the first piece of data to reserve 10 spaces
		// and the second to reserve 5.
		
		//After the number, I use 1 letter to represent the type of data.
		// s is for Strings.  d is for integers and f is for doubles. 
		// c is for a single character.  
		
		//The - indicates that I want the data to be left justified
		//Leaving a dash out would automatically right-justify the data
		//Rerun this with the dash removed from the line above.
		
		//Here's another example:
		
		String first = "Buster";
		String last = "Bluth";
		System.out.format("%25s %15s %10.2f",first,last,gpa);
	
		//Here I'm specifying two digits to the right of the decimal.
		
	}
}
